var mongoose = require("mongoose");
var Schema = mongoose.Schema;
const bcrypt = require('bcryptjs');

var userSchema = new Schema({
    "userName":  {
        "type": String,
        "unique": true
    },
    "password": String,
    "email": String,
    "loginHistory": [{
      "dateTime": Date,
        "userAgent": String
    }]
  });
  
  let User;

  module.exports.initialize = function () {
    return new Promise(function (resolve, reject) {
    let db = mongoose.createConnection("mongodb://fenil:1234@ds039860.mlab.com:39860/web322_a6");
    db.on('error', (err)=>{
    reject(err); // reject the promise with the provided error
    });
    db.once('open', ()=>{
    User = db.model("users", userSchema);
    resolve();
    });
    });
   };




   //registerUser
   module.exports.registerUser = (userData)=>{
    return new Promise((resolve, reject)=> {
       if(userData.password != userData.password2){
           reject("Passwords do not match");
       }else{
        bcrypt.genSalt(10, function(err, salt) { // Generate a "salt" using 10 rounds
        bcrypt.hash(userData.password, salt, function(err, hash) { // encrypt the password: "myPassword123"
        // TODO: Store the resulting "hash" value in the DB
        if (err) {
            reject("There was an error encrypting the password");
        }
        userData.password = hash;

        let newUser = new User(userData);
        newUser.save((err)=> {
            if(err){
                if(err.code == 11000){
                    console.log("user name already taken");
                    reject("User Name already taken");
                }else{
                    reject("There was an error creating the user: " + err);
                }
          }
          else{
            resolve();
          }
        });
        });
       });
        
    };
});
}


//checkUser
module.exports.checkUser = (userData) =>{
    return new Promise((resolve, reject) => {
        User.find({userName: userData.userName})
    .exec()
    .then((users) => {
      if(users.length == 0) {
        reject("Unable to find user: " + userData.userName);
      }else{
          let hash = users[0].password;
        bcrypt.compare(userData.password, hash).then((res) => {
             if(res === false){
                    reject("Unable to find user: user");
            }else{
                users[0].loginHistory.push({dateTime: (new Date()).toString(), userAgent: userData.userAgent})
                User.update({ userName: users[0].userName},
                    { $set: { loginHistory: users[0].loginHistory } },
                    { multi: false })
                    .exec()
                    .then(()=>{resolve(users[0]);})
                    .catch((err)=>{
                        reject("error");
                    }).catch((err)=>{
                reject("There was an error verifying the user: ${err}");

            })
           }  
    })
}
}).catch("Unable to finduser:" +  userData.user);
    });
};
  

   