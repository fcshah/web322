/*********************************************************************************
* WEB322 – Assignment 02
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students.
*
* Name: Fenil shah Student ID:#146878160 Date: 11/02/2018
*
* Online (Heroku) Link:  https://secure-stream-56434.herokuapp.com/
*
********************************************************************************/ 
var express = require("express");
var app = express();
var path = require("path");
var DataServ = require("./data-service.js");
app.use(express.static('public'));
var HTTP_PORT = process.env.PORT || 8080;
app.listen(HTTP_PORT, onHttpStart);
function onHttpStart() {
        console.log("Express http server listening on: " + HTTP_PORT);
           DataServ.initialize().then((data)=>{
               console.log(data)
             }).catch((err)=>{
               console.log(err);
        });
}

app.get('/',(req, res)=>{
   res.sendFile(path.join(__dirname + '/views/home.html'));
});
app.get('/about',(req, res)=>{
    res.sendFile(path.join(__dirname + '/views/about.html'));
});
app.get("/employees",(req,res)=>{
    DataServ.getAllEmployees().then((data)=>{
        res.json(data);
      }).catch((err)=>{
        res.json({message: err});
      });
});
app.get("/managers",(req,res)=>{
      DataServ.getManagers().then((data)=>{
        res.json(data);
      }).catch((err)=>{
        res.json({message: err});
      });
});
app.get("/departments",(req,res)=>{
      DataServ.getDepartments().then((data)=>{
        res.json(data);
      }).catch((err)=>{
        res.json({message: err});
      });
});
app.use((req, res)=>{
  res.status(404).send("!....Page Not Found....!");
});

