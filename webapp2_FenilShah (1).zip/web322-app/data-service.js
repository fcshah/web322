var fs = require("fs");

var employees = []; 
var departments = []; 

module.exports.initialize = function(){
    return new Promise(function(resolve,reject){
        try{
            fs.readFile('./data/employees.json', function(err, data){
                if(err) throw err;
                employees = JSON.parse(data);
            });
            fs.readFile('./data/departments.json', function(err,data){
                if(err) throw err;
                departments = JSON.parse(data);
            });
        }catch(ex){
            reject("File not read");
        }
    });
}

module.exports.getAllEmployees = function(){
    var Empl=[];
    return new Promise(function(resolve,reject){
        for (var i = 0; i < employees.length; i++) {
            Empl.push(employees[i]);
        }
        if (Empl.length == 0){
            reject("File not read");
        }
    resolve(Empl);
    })
}

module.exports.getManagers = function() {
    var Mang = [];
    return new Promise(function(resolve,reject){
        if(employees.length == 0){
            reject("No Result");
        }else{
            for (var q = 0; q < employees.length; q++) {
                 if (employees[q].isManager == true) {
                    Mang.push(employees[q]);       
                 }
            }
            if (Mang.length == 0) {
                     reject("No Result");
             }
        }
        resolve(Mang);
     });
}

module.exports.getDepartments = function() {
    var Dept = [];
    return new Promise(function(resolve,reject){
        if(employees.length == 0){
            reject("No Result");
        }else{
            for (var v = 0; v < departments.length; v++) {
                Dept.push(departments[v]);       
            }
            if (Dept.length == 0) {
                reject("No Result");
            }
        }
    resolve(Dept);
    });
}