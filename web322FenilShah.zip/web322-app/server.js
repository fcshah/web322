/*********************************************************************************
*  WEB322 –Assignment02
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part 
*  of this assignment has been copied manually or electronically from any other source 
*  (including 3rd party web sites) or distributed to other students.
* 
*  Name:Fenil Shah Student ID: 146878160 Date: 28/02/2018
*
*  Online (Heroku) Link:  https://intense-wave-84759.herokuapp.com/
*
********************************************************************************/ 
var express = require("express");
var app = express();
var path = require("path");
var multer=require("multer");
var fs=require('fs');
var bodyParser=require('body-parser')
app.use(bodyParser.urlencoded({extended:true}));
var data_service = require("./data-service.js");
app.use(express.static('public'));
var HTTP_PORT = process.env.PORT || 8080;
function onHttpStart() {
        console.log("Express http server listening on: " + HTTP_PORT);
           data_service.initialize().then(function(data){
               console.log(data)
             }).catch(function(err){
               console.log(err);
             });
}

app.get('/', function(req, res){
   res.sendFile(path.join(__dirname + '/views/home.html'));
});
app.get('/about', function(req, res){
    res.sendFile(path.join(__dirname + '/views/about.html'));
});
app.get("/employee/:num(\\d+)/", function(req,res){
  
  data_service.getEmployeeByNum(req.params.num).then(function(data){
    res.json(data);
  }).catch(function(err){
      res.json({message: err});
  });

});
app.get("/employees", function(req,res){
  if(req.query.status){
    data_service.getEmployeesByStatus(req.query.status).then(function(data){
      res.json(data);
    }).catch(function(err){
      res.json({message: err });
    });
  }else if(req.query.department){
    data_service.getEmployeesByDepartment(req.query.department).then(function(data){
      res.json(data);
    }).catch(function(err){
      res.json({message: err});
    });
  }else if(req.query.manager){
    data_service.getEmployeesByManager(req.query.manager).then(function(data){
      res.json(data);
    }).catch(function(err){
      res.json({message: err});
    });
  }else{
    data_service.getAllEmployees().then(function(data){
      res.json(data);
    }).catch(function(err){
      res.json({message: err });
    });
  }
});

app.get("/managers", function(req,res){
      data_service.getManagers().then(function(data){
        res.json(data);
      }).catch(function(err){
        res.json({message: err});
      });
});
app.get("/departments", function(req,res){
      data_service.getDepartments().then(function(data){
        res.json(data);
      }).catch(function(err){
        res.json({message: err});
      });
});
app.get('/employees/add', function(req, res){
  res.sendFile(path.join(__dirname + '/views/addEmployee.html'));
});
app.get('/images/add', function(req, res){
  res.sendFile(path.join(__dirname + '/views/addImage.html'));
});
var storage = multer.diskStorage({
  destination: "./public/images/uploaded",
  filename:function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
    }
});
var upload = multer({ storage: storage });
app.post('/images/add',upload.single("imageFile"), function(req, res){
  res.redirect("/images");
});
app.get("/images",function(req,res){
  fs.readdir("./public/images/uploaded", function(err, items){
    res.json({images:items});
  });
});
app.post("/employees/add",function(req,res){
  data_service.addEmployee(req.body).then(function(data){
    res.redirect("/employees");
  });
});
app.use(function(req, res) {
  res.status(404).send("   Page unavailable!!!!! ");
});
app.listen(HTTP_PORT, onHttpStart);
