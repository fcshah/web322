var fs = require("fs");
var employees = []; 
var departments = []; 

module.exports.initialize = function(){
    return new Promise(function(resolve,reject){
        try{
            fs.readFile('./data/employees.json', function(err, data){
                if(err) throw err;
                employees = JSON.parse(data);
            });
            fs.readFile('./data/departments.json', function(err,data){
                if(err) throw err;
                departments = JSON.parse(data);
            });
        }catch(ex){
            reject("File not reading.....");
        }
    });
}

module.exports.getAllEmployees = function(){
    var Employees=[];
    return new Promise(function(resolve,reject){
        for (var i = 0; i < employees.length; i++) {
            Employees.push(employees[i]);
        }
        if (Employees.length == 0){
            reject("Nothing to Return");
        }
    resolve(Employees);
    })
}

module.exports.getManagers = function() {
    var Managers = [];
    return new Promise(function(resolve,reject){
        if(employees.length == 0){
            reject("Nothing to Return");
        }else{
            for (var i = 0; i < employees.length; i++) {
                 if (employees[i].isManager == true) {
                    Managers.push(employees[i]);       
                 }
            }
            if (Managers.length == 0) {
                     reject("Nothing to Return");
             }
        }
        resolve(Managers);
     });
}

module.exports.getDepartments = function() {
    var Departments = [];
    return new Promise(function(resolve,reject){
        if(employees.length == 0){
            reject("Nothing to return");
        }else{
            for (var i = 0; i < departments.length; i++) {
                Departments.push(departments[i]);       
            }
            if (Departments.length == 0) {
                reject("Nothing to Fund");
            }
        }
    resolve(Departments);
    });
}
module.exports.addEmployee=function(employeeData){
    return new Promise(function(resolve,reject){
        employeeData.isManager=(!employeeData.isManager)?false:true;
        employeeData.employee=(employees.length+1);
        employees.push(employeeData);
        if(employeeData==0){
            reject("No result found");
        }else{
            resolve(employees);
        }
    });
}
module.exports.getEmployeesByStatus = function(status){
    var arrayByStatus = [];
    return new Promise(function(resolve,reject){
        for(var i = 0; i < employess.length; i++){
            if(employess[i].status == status){
                arrayByStatus.push(employess[i]);
            }
        }
        if (arrayByStatus.length == 0){
            reject("Nothing to return");
        }
        resolve(arrayByStatus);
    });
}

module.exports.getEmployeesByDepartment = function(department){
    var arrayByDepartment = [];
    return new Promise(function(resolve,reject){
        for(var i = 0; i < employess.length; i++){
            if(employess[i].department == department){
                arrayByDepartment.push(employess[i]);
            }
        }
        if(arrayByDepartment.length == 0){
            reject("Nothing to return");
        }
    resolve(arrayByDepartment);
    });
}

module.exports.getEmployeesByManager = function(manager) {
    var arrayGetEmployeesByMannager = [];

    return new Promise(function(resolve,reject) {
        for (var i = 0; i < employess.length; i++) {
            if (employess[i].employeeManagerNum == manager) {
                arrayGetEmployeesByMannager.push(employess[i]);
            }
        }
        if (arrayGetEmployeesByMannager.length == 0 ) {
            reject("Nothing to return");
        }
    resolve(arrayGetEmployeesByMannager);
    });
}

module.exports.getEmployeeByNum = function(num) {
    var arrayGetEmployeesByValue=[];
    return new Promise(function(resolve,reject){
        for (var i = 0; i < employees.length; i++) {
            if(employees[i].employeeNum == num){
            arrayGetEmployeesByValue.push(employees[i]);
            }
        }
        if (arrayGetEmployeesByValue.length == 0){
            reject("Nothing to return");
        }
    resolve(arrayGetEmployeesByValue);
    });
}